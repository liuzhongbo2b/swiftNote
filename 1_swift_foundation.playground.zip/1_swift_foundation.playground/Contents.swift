//
//  main.swift
//  1_swift_foundation
//
//  Created by 田逸昕 on 08/03/2018.
//  Copyright © 2018 田逸昕. All rights reserved.
//

import Foundation

//swift是区分大小写的
//首字母可以是下划线（ _ ）或者 字母，不能!!!是数字!!
//除了首字母，其他的可以是下划线、字母或者数字
//甚至可以是emoji，比如☺️☺️😭😭😂😭，但是并不推荐，看上去好玩，但是代码就不好理解了

//要是真的想用关键词当标识符，可以加重音符号 " ` "，注意，不是单引号，我也不知道怎么打出来的
let `class` = "class"
print(`class`)
//但是根本没必要这样，因为这不是个好习惯，代码会更加不好理解，而且这个符号键盘上没有，不好输入


//常用的带有“#”的关键字
// #column：所在的列数
// #line：所在的行数
// #file：所在的文件名
// #function：所在函数的名字
//比如下面这个函数就是将该函数的信息输出出来
func log(message: String){
    print("Function:\(#function) COLUMN:\(#column) FILE:\(#file) LINE:\(#line) \(message)")
}
log(message: "Test")


//声明常量是用“ let ”
let _hello = "hello"
print(_hello)
//若再次给常量赋值会报错
//let _hello = "yep"

//声明变量是用“ var ”
var _haiya = "haiya"
print(_haiya)
//可以一句声明多个“相同”类型变量
var x = 10, y = 20
//可以一句声明多个“不同”类型的变量
var p = 1, q = true


//声明变量或者常量可以指定类型，也可以不指定，因为！！！
//swift会自己推断出来！！你给的是什么类型的值，是不是很聪明😝
//上面的都没指定类型，下面的这句我们指定了整型
let one: Int = 1

//使用let声明的东西会更多一些，因为这些声明的量意味着不可更改，便于阅读


//关于分号的问题，其他的语言众所周知都要在句尾加分号
//swift是不用的！！！
//但是要是一行有好几句话，那就得加，比如
var aaa = 1; var bbb = 2

//单行注释用“ // ”
//多行注释像这样,但是！！！多行注释可以嵌套，一个多行注释可以套一个多行注释，像套娃一样，但是得成对
/*
 1
 /*
 2
 2
 2
 */
 1
 1
 */
//小贴士：print默认换行，加参数terminator，引号内的东西就是取代换行符的东西，比如下面我们让“-”取代了换行
var i = 1
while i <= 10 {
    print("\(i)", terminator: "-")
    i += 1
}





